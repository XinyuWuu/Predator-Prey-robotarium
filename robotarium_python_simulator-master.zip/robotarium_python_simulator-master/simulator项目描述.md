simulator.py 用来实现项目需求中环境完善的部分

example.py 是simulator的示例代码
